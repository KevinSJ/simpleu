wget https://raw.githubusercontent.com/vokins/simpleu/master/hosts
wget https://raw.githubusercontent.com/vokins/simpleu/master/tools/hosts.zip
chmod +x fastboot-linux
./fastboot-linux adb devices
adb root
adb remount
adb push hosts /etc/hosts
adb shell chmod 644 /etc/hosts
adb shell reboot
